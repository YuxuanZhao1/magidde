#' Test dynamic system model specification
#'
#' Given functions for the DE and its gradients (with respect to the system components and parameters), verify the correctness of the gradients using numerical differentiation.
#'
#' @param modelDE function that computes the DEs, specified with the form \code{f(theta, x, tvec)}. See examples.
#' @param modelDx function that computes the gradients of the DEs with respect to the system components. See examples.
#' @param modelDtheta function that computes the gradients of the DEs with respect to the parameters \eqn{\theta}. See examples.
#' @param modelName string giving a name for the model
#' @param x data matrix of system values, one column for each component, at which to test the gradients
#' @param theta vector of parameter values for \eqn{\theta}, at which to test the gradients
#' @param tvec vector of time points corresponding to the rows of \code{x}
#' 
#' @details Calls \code{\link[testthat]{test_that}} to test equality of the analytic and numeric gradients.
#' 
#' @return A list with elements \code{testDx} and \code{testDtheta}, each with value \code{TRUE} if the corresponding gradient check passed and \code{FALSE} if not.
#'  
#' @export
testDynamicalModel <- function(modelODE, modelDx, modelDtheta, modelName, x, theta, tvec){
  msg <- paste(modelName, "model, with derivatives\n")
  success <- TRUE
  f <- modelODE(theta, x, tvec)
  deltaSmall <- 1e-06
  numericalDx <- sapply(1:ncol(x), function(j) {
    sapply(1:nrow(x), function(i) {
      xnew <- x
      xnew[i, j] <- xnew[i, j] + deltaSmall
      (modelODE(theta, xnew, tvec) - f)/deltaSmall
    }, simplify = "array")
  }, simplify = "array")
  fdXraw <- modelDx(theta, x, tvec)
  fdX <- array(NA, dim = c(nrow(fdXraw), nrow(fdXraw), length(tvec), length(tvec)))
  for (i in 1:nrow(fdXraw)) {
    for (j in 1:nrow(fdXraw)) {
      if(length(fdXraw[i,j][[1]]) == length(tvec))
        fdX[i,j,,] <- diag(as.vector(fdXraw[i,j][[1]]))
      else
        fdX[i,j,,] <- fdXraw[i,j][[1]]
    }
  }
  
  testDx <- TRUE
  if (!all(abs(fdX - aperm(numericalDx, c(4, 2, 3, 1))) < 1e-04)) {
    success <- FALSE
    testDx <- FALSE
    msg <- paste0(msg, "Dx may not be consistent with f, further checking is advised\n")
  }
  
  f <- modelODE(theta, x, tvec)
  deltaSmall <- 1e-06
  numericalDtheta <- sapply(1:length(theta), function(i) {
    thetaNew <- theta
    thetaNew[i] <- theta[i] + deltaSmall
    (modelODE(thetaNew, x, tvec) - f)/deltaSmall
  }, simplify = "array")
  fDtheta <- modelDtheta(theta, x, tvec)
  if (!all(abs(fDtheta - aperm(numericalDtheta, c(1, 3, 2))) <
           1e-04)) {
    success <- FALSE
    msg <- paste0(msg, "Dtheta may not be consistent with f, further checking is advised\n")
    testDtheta <- FALSE
  }
  else {
    testDtheta <- TRUE
  }
  if (success) {
    msg <- paste0(msg, "Dx and Dtheta appear to be correct\n")
  }
  cat(msg)
  list(testDx = testDx, errorDx = abs(fdX - aperm(numericalDx, c(4, 2, 3, 1))), testDtheta = testDtheta, errorDtheta = abs(fDtheta - aperm(numericalDtheta, c(1, 3, 2))))
}
