#' @useDynLib magidde
#' @import Rcpp 
NULL

