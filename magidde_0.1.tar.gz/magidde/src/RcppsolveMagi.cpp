#include "RcppArmadillo.h"
#include "classDefinition.h"
#include "Sampler.h"
#include "MagiSolver.h"
#include "dynamicalSystemModels.h"
#include "RcppTranslation.h"

using namespace Rcpp;

// [[Rcpp::export]]
Rcpp::List solveMagiRcpp(
        const arma::mat & yFull,
        const List & odeModel,
        const arma::vec & tvecFull,
        const arma::vec & sigmaExogenous,
        const arma::mat & phiExogenous,
        const arma::mat & xInitExogenous,
        const arma::vec & thetaInitExogenous,
        const arma::mat & muExogenous,
        const arma::mat & dotmuExogenous,
        const double priorTemperatureLevel,
        const double priorTemperatureDeriv,
        const double priorTemperatureObs,
        const std::string kernel,
        const int nstepsHmc,
        const double burninRatioHmc,
        const unsigned int niterHmc,
        const arma::vec stepSizeFactorHmc,
        const int nEpoch,
        const int bandSize,
        const bool useFrequencyBasedPrior,
        const bool useBand,
        const bool useMean,
        const bool useScalerSigma,
        const bool useFixedSigma,
        const bool skipMissingComponentOptimization,
        const bool positiveSystem,
        const bool verbose) {

    OdeSystem modelC;
    //model = OdeSystem(fOde, fOdeDx, fOdeDtheta, lb, ub);
    //const Rcpp::Function fOdeR = odeModel["fOde"];
    //const Rcpp::Function fOdeDxR = odeModel["fOdeDx"];
    //const Rcpp::Function fOdeDthetaR = odeModel["fOdeDtheta"];
    const Rcpp::String modelName = odeModel.containsElementNamed("name") ? as<Rcpp::String>(odeModel["name"]) : "";
    if(modelName == "lvD"){
        modelC = OdeSystem(lvDDE, lvDDx, lvDDtheta, arma::zeros(3), arma::ones(3)*INFINITY);
    }else if(modelName == "SIR"){
        modelC = OdeSystem(sirDDE, sirDDx, sirDDtheta, arma::zeros(5), arma::ones(5)*INFINITY);
    }else if(modelName == "SIRtwo"){
        modelC = OdeSystem(sirtwoDDE, sirtwoDDx, sirtwoDDtheta, arma::zeros(7), arma::ones(7)*INFINITY);}
    else if(modelName == "SIRtwobwo"){
        modelC = OdeSystem(sirtwobwoDDE, sirtwobwoDDx, sirtwobwoDDtheta, arma::zeros(6), arma::ones(6)*INFINITY);}
    else if(modelName == "SIRD"){
        modelC = OdeSystem(sirdDDE, sirdDDx, sirdDDtheta, arma::zeros(4), arma::ones(4)*INFINITY);}
    else if(modelName == "IRD"){
        modelC = OdeSystem(irdDDE, irdDDx, irdDDtheta, arma::zeros(4), arma::ones(4)*INFINITY);}
    else if(modelName == "lacoperon"){
        modelC = OdeSystem(lacoperonDDE, lacoperonDDx, lacoperonDDtheta, arma::zeros(3), arma::ones(3)*INFINITY);
    }else if(modelName == "lacoperonwpars"){
        modelC = OdeSystem(lacoperonparsDDE, lacoperonparsDDx, lacoperonparsDDtheta, arma::zeros(8), {25, 25, 25, INFINITY,INFINITY,INFINITY,INFINITY,INFINITY});
	  }else{
        const Rcpp::Function & fOdeR = as<const Function>(odeModel["fOde"]);
        const Rcpp::Function & fOdeDxR = as<const Function>(odeModel["fOdeDx"]);
        const Rcpp::Function & fOdeDthetaR = as<const Function>(odeModel["fOdeDtheta"]);


        const Rcpp::NumericVector & thetaLowerBoundR = as<const NumericVector>(odeModel["thetaLowerBound"]);
        const Rcpp::NumericVector & thetaUpperBoundR = as<const NumericVector>(odeModel["thetaUpperBound"]);

        modelC.thetaUpperBound = arma::vec(const_cast<double*>( &(thetaUpperBoundR[0])), thetaUpperBoundR.size(), false, false);
        modelC.thetaLowerBound = arma::vec(const_cast<double*>( &(thetaLowerBoundR[0])), thetaLowerBoundR.size(), false, false);
        modelC.thetaSize = modelC.thetaLowerBound.size();

        modelC.fOde = [fOdeR](const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) -> arma::mat {
            return r2armamat(fOdeR(theta, x, tvec));
        };

        modelC.fOdeDx = [fOdeDxR](const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) -> arma::field<arma::mat> {
            return arma::field<arma::mat>(1,1);
            //return r2armacube(fOdeDxR(theta, x, tvec));
        };

        modelC.fOdeDtheta = [fOdeDthetaR](const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) -> arma::cube {
            return r2armacube(fOdeDthetaR(theta, x, tvec));
        };
    }

    MagiSolver solver(yFull,
                      modelC,
                      tvecFull,
                      sigmaExogenous,
                      phiExogenous,
                      xInitExogenous,
                      thetaInitExogenous,
                      muExogenous,
                      dotmuExogenous,
                      priorTemperatureLevel,
                      priorTemperatureDeriv,
                      priorTemperatureObs,
                      kernel,
                      nstepsHmc,
                      burninRatioHmc,
                      niterHmc,
                      stepSizeFactorHmc,
                      nEpoch,
                      bandSize,
                      useFrequencyBasedPrior,
                      useBand,
                      useMean,
                      useScalerSigma,
                      useFixedSigma,
                      skipMissingComponentOptimization,
                      positiveSystem,
                      verbose);


    solver.setupPhiSigma();
    if(verbose){
        Rcpp::Rcout << "phi = \n" << solver.phiAllDimensions << "\n";
    }
    solver.initXmudotmu();

    solver.initTheta();
    if(verbose){
        Rcpp::Rcout << "thetaInit = \n" << solver.thetaInit << "\n";
    }

    //return yFull;
    solver.initMissingComponent();
    solver.sampleInEpochs();

    Rcpp::List ret = Rcpp::List::create(Rcpp::Named("llikxthetasigmaSamples")=solver.llikxthetasigmaSamples,
                                        Rcpp::Named("phi")=solver.phiAllDimensions);

    return ret;

}
