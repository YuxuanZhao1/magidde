#include "dynamicalSystemModels.h"

using namespace arma;
using namespace std;

arma::field<arma::sp_mat> calcDelay(const arma::vec & tvec, double tau) {
  umat loc(2, 2*tvec.n_elem);
  vec values(2*tvec.n_elem);
  vec valuesDtau(2*tvec.n_elem);

  double tdelta = tvec[1] - tvec[0]; // assume equally spaced
  int tauOffset = std::max(std::ceil(tau / tdelta), 1.0);
  double wgt = (tau - tdelta*tauOffset) / tdelta + 1;

  for (unsigned int i=0; i < tvec.n_elem; i++) {
    if (i < tauOffset) {
      loc.col(2*i) = {i,0};
      loc.col(2*i+1) = {i,1};
      values(2*i) = 1;
      values(2*i+1) = 0;
      valuesDtau(2*i) = 0;
      valuesDtau(2*i+1) = 0;
    } else {
      loc.col(2*i) = {i,i-tauOffset};
      loc.col(2*i+1) = {i,i-tauOffset+1};
      values(2*i) = wgt;
      values(2*i+1) = 1.0 - wgt;
      valuesDtau(2*i) = 1.0 / tdelta;
      valuesDtau(2*i+1) = -1.0 / tdelta;
    }
  }
  //Rcpp::Rcout << "Atau = " << Atau << std::endl;

  field<sp_mat> Atau(2);
  Atau(0) = sp_mat(loc, values, tvec.n_elem, tvec.n_elem);
  Atau(1) = sp_mat(loc, valuesDtau, tvec.n_elem, tvec.n_elem);

  return Atau;
}

// [[Rcpp::export]]
arma::mat lvDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  // theta = r, K, tau
  mat dxdt(x.n_rows, x.n_cols);
  field<sp_mat> Atau = calcDelay(tvec, theta(2));
  
  dxdt.col(0) = theta(0) * (1 - exp(Atau(0) * x.col(0))/(1000 * theta(1)));

  //Rcpp::Rcout << "dxdt = " << dxdt << std::endl;
  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> lvDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
  // theta = r, K, tau
  field<sp_mat> Atau = calcDelay(tvec, theta(2));
  resultDx(0,0) = mat(x.n_rows, x.n_rows);

  resultDx(0,0) = theta(0) * (- Atau(0).t() * diagmat(exp(Atau(0) * x.col(0)))/(1000 * theta(1)));

  //Rcpp::Rcout << "Dx = " << M_0 << std::endl;

  return resultDx;
}

// [[Rcpp::export]]
arma::cube lvDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols, fill::zeros);
  field<sp_mat> Atau = calcDelay(tvec, theta(2));

  resultDtheta.slice(0).col(0) = 1 - exp(Atau(0) * x.col(0))/(1000 * theta(1));
  resultDtheta.slice(0).col(1) = theta(0) * (exp(Atau(0) * x.col(0))/(1000 * pow(theta(1),2)));
  resultDtheta.slice(0).col(2) = theta(0) * ( (-Atau(1) * x.col(0)) % exp(Atau(0) * x.col(0))/(1000 * theta(1)));
      
  //Rcpp::Rcout << "Dtheta = " << resultDtheta << std::endl;
  return resultDtheta;
}



// [[Rcpp::export]]
arma::mat sirDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double mu = theta(1);
  const double h = theta(2);
  const double lambda = theta(3);
  const double eta = theta(4);

  field<sp_mat> Itau = calcDelay(tvec, h);

  dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  dxdt.col(2) = lambda * I - mu * R;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> sirDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
   for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if (((i == 0) && (j == 1)) || ((i == 1) && (j == 1)))
        resultDx(j, i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j, i) = mat(x.n_rows, 1);
    }
  }

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double mu = theta(1);
  const double h = theta(2);
  const double lambda = theta(3);
  const double eta = theta(4);

  field<sp_mat> Itau = calcDelay(tvec, h);

  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;

  resultDx(0, 0).col(0) = -beta * exp(-mu * h) * Itau(0) * I - mu; 
  resultDx(1, 0) = Itau(0).t() * diagmat(-beta * exp(-mu * h) * S);

  resultDx(0, 1).col(0) = beta * exp(-mu * h) * Itau(0) * I;
  resultDx(1, 1) =  Itau(0).t() * diagmat(beta * exp(-mu * h) * S) - diagmat(arma::ones(tvec.n_elem) * (mu + lambda));

  resultDx(1, 2).col(0).fill(lambda);
  resultDx(2, 2).col(0).fill(-mu);
  
  return resultDx;
}

// [[Rcpp::export]]
arma::cube sirDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double mu = theta(1);
  const double h = theta(2);
  const double lambda = theta(3);
  const double eta = theta(4);

  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;  

  field<sp_mat> Itau = calcDelay(tvec, h);

  resultDtheta.slice(0).col(0) = - exp(-mu * h) * S % (Itau(0) * I);
  resultDtheta.slice(0).col(1) =  beta * S % (Itau(0) * I) * h * exp(-mu * h) - S;
  resultDtheta.slice(0).col(2) = -beta * ( S % (Itau(1) * I)*exp(- mu * h)  - mu * exp(-mu * h) * S % (Itau(0) * I)); 
  resultDtheta.slice(0).col(4).fill(1);

  resultDtheta.slice(1).col(0) = exp(-mu * h) * S %( Itau(0) * I);
  resultDtheta.slice(1).col(1) = -beta * S % (Itau(0) * I) * h * exp(-mu * h) - I;
  resultDtheta.slice(1).col(2) = beta * (exp(- mu * h) * (Itau(1) * I) % S - mu * exp(-mu * h) * (Itau(0) * I) % S); 
  resultDtheta.slice(1).col(3) = -I;

  resultDtheta.slice(2).col(1) = -R;
  resultDtheta.slice(2).col(3) = I; 

  return resultDtheta;
}


// [[Rcpp::export]]
arma::mat sirtwoDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);
  const double b = theta(6);

  field<sp_mat> Itau = calcDelay(tvec, h);

  dxdt.col(0) = -beta * S % (Itau(0) * I) - mu_1 * S + b;
  dxdt.col(1) = beta * S % (Itau(0) * I) - mu_2 * I - lambda * I;
  dxdt.col(2) = lambda * I - mu_3 * R;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> sirtwoDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
   for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if (((i == 0) && (j == 1)) || ((i == 1) && (j == 1)))
        resultDx(j, i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j, i) = mat(x.n_rows, 1);
    }
  }

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);
  const double b = theta(6);

  field<sp_mat> Itau = calcDelay(tvec, h);

  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;

  resultDx(0, 0).col(0) = -beta * Itau(0) * I - mu_1;
  resultDx(1, 0) = Itau(0).t() * diagmat(-beta *  S);

  resultDx(0, 1).col(0) = beta * Itau(0) * I ;
  resultDx(1, 1) = Itau(0).t() * diagmat(beta *  S) - diagmat(arma::ones(tvec.n_elem) * (mu_2 + lambda));

  resultDx(1, 2).col(0).fill(lambda);
  resultDx(2, 2).col(0).fill(-mu_3);
  
  return resultDx;
}

// [[Rcpp::export]]
arma::cube sirtwoDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);
  const double b = theta(6);
  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;

  field<sp_mat> Itau = calcDelay(tvec, h);

  resultDtheta.slice(0).col(0) = - S % (Itau(0) * I);
  resultDtheta.slice(0).col(1) = - beta * S  % (Itau(1) * I);
  resultDtheta.slice(0).col(2) = - S;
  resultDtheta.slice(0).col(6).fill(1);

  resultDtheta.slice(1).col(0) = S % (Itau(0) * I);
  resultDtheta.slice(1).col(1) = beta * S  % (Itau(1) * I);
  resultDtheta.slice(1).col(3) = -I;
  resultDtheta.slice(1).col(5) = -I;

  resultDtheta.slice(2).col(4) = -R;
  resultDtheta.slice(2).col(5) = I;

  return resultDtheta;
}

// [[Rcpp::export]]
arma::mat sirtwobwoDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);


  field<sp_mat> Itau = calcDelay(tvec, h);

  dxdt.col(0) = -beta * S % (Itau(0) * I) - mu_1 * S;
  dxdt.col(1) = beta * S % (Itau(0) * I) - mu_2 * I - lambda * I;
  dxdt.col(2) = lambda * I - mu_3 * R;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> sirtwobwoDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
   for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if (((i == 0) && (j == 1)) || ((i == 1) && (j == 1)))
        resultDx(j, i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j, i) = mat(x.n_rows, 1);
    }
  }

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);


  field<sp_mat> Itau = calcDelay(tvec, h);

  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;

  resultDx(0, 0).col(0) = -beta * Itau(0) * I - mu_1;
  resultDx(1, 0) = Itau(0).t() * diagmat(-beta *  S);

  resultDx(0, 1).col(0) = beta * Itau(0) * I ;
  resultDx(1, 1) = Itau(0).t() * diagmat(beta *  S) - diagmat(arma::ones(tvec.n_elem) * (mu_2 + lambda));

  resultDx(1, 2).col(0).fill(lambda);
  resultDx(2, 2).col(0).fill(-mu_3);
  
  return resultDx;
}

// [[Rcpp::export]]
arma::cube sirtwobwoDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_1 = theta(2);
  const double mu_2 = theta(3);
  const double mu_3 = theta(4);
  const double lambda = theta(5);

  // dxdt.col(0) = -beta * exp(-mu * h) * S % (Itau(0) * I) - mu * S + eta;
  // dxdt.col(1) = beta * exp(-mu * h) * S % (Itau(0) * I) - mu * I - lambda * I;
  // dxdt.col(2) = lambda * I - mu * R;

  field<sp_mat> Itau = calcDelay(tvec, h);

  resultDtheta.slice(0).col(0) = - S % (Itau(0) * I);
  resultDtheta.slice(0).col(1) = - beta * S  % (Itau(1) * I);
  resultDtheta.slice(0).col(2) = - S;


  resultDtheta.slice(1).col(0) = S % (Itau(0) * I);
  resultDtheta.slice(1).col(1) = beta * S  % (Itau(1) * I);
  resultDtheta.slice(1).col(3) = -I;
  resultDtheta.slice(1).col(5) = -I;

  resultDtheta.slice(2).col(4) = -R;
  resultDtheta.slice(2).col(5) = I;

  return resultDtheta;
}


// [[Rcpp::export]]
arma::mat sirdDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & S = x.col(0);
  const vec & I = x.col(1);
  const vec & R = x.col(2);
  const vec & D = x.col(3);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);


  field<sp_mat> Itau = calcDelay(tvec, h);

  dxdt.col(0) = -beta * S % (Itau(0) * I) ;
  dxdt.col(1) = beta * S % (Itau(0) * I) - mu_2 * I - lambda * I;
  dxdt.col(2) = lambda * I ;
  dxdt.col(3) =  mu_2 * I;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> sirdDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
   for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if (((i == 0) && (j == 1)) || ((i == 1) && (j == 1)))
        resultDx(j, i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j, i) = mat(x.n_rows, 1);
    }
  }

    const vec & S = x.col(0);
    const vec & I = x.col(1);
    const vec & R = x.col(2);
    const vec & D = x.col(3);

 
  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);


  field<sp_mat> Itau = calcDelay(tvec, h);


  resultDx(0, 0).col(0) = -beta * Itau(0) * I;
  resultDx(1, 0) = Itau(0).t() * diagmat(-beta *  S);

  resultDx(0, 1).col(0) = beta * Itau(0) * I ;
  resultDx(1, 1) = Itau(0).t() * diagmat(beta *  S) - diagmat(arma::ones(tvec.n_elem) * (mu_2 + lambda));

  resultDx(1, 2).col(0).fill(lambda);

  resultDx(1, 3).col(0).fill(mu_2);
 
  return resultDx;
}

// [[Rcpp::export]]
arma::cube sirdDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

    const vec & S = x.col(0);
    const vec & I = x.col(1);
    const vec & R = x.col(2);
    const vec & D = x.col(3);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);


  field<sp_mat> Itau = calcDelay(tvec, h);

  resultDtheta.slice(0).col(0) = - S % (Itau(0) * I);
  resultDtheta.slice(0).col(1) = - beta * S  % (Itau(1) * I);



  resultDtheta.slice(1).col(0) = S % (Itau(0) * I);
  resultDtheta.slice(1).col(1) = beta * S  % (Itau(1) * I);
  resultDtheta.slice(1).col(2) = -I;
  resultDtheta.slice(1).col(3) = -I;


  resultDtheta.slice(2).col(3) = I;
    

   resultDtheta.slice(3).col(2) = I;

    

  return resultDtheta;
}

// [[Rcpp::export]]
arma::mat irdDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & I = x.col(0);
  const vec & R = x.col(1);
  const vec & D = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);

  field<sp_mat> Itau = calcDelay(tvec, h);

  dxdt.col(0) = beta * (1 - I  - R  - D ) % (Itau(0) * I) - mu_2 * I - lambda * I;
  dxdt.col(1) = lambda * I;
  dxdt.col(2) = mu_2 * I;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> irdDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
   for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if (((i == 0) && (j == 0)))
        resultDx(j, i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j, i) = mat(x.n_rows, 1);
    }
  }

  const vec & I = x.col(0);
  const vec & R = x.col(1);
  const vec & D = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);

  field<sp_mat> Itau = calcDelay(tvec, h);

  // dxdt.col(0) = beta * (1 - I  - R  - D ) % (Itau(0) * I) - mu_2 * I - lambda * I;
  // dxdt.col(1) = lambda * I;
  // dxdt.col(2) = mu_2 * I;

  resultDx(0, 0) = Itau(0).t() * diagmat(beta * (1 - I - R - D)) - beta * diagmat(Itau(0) * I) - diagmat(arma::ones(tvec.n_elem) * (mu_2 + lambda));

  resultDx(1, 0).col(0) =  -beta * Itau(0) * I;
  resultDx(2, 0).col(0) =  -beta * Itau(0) * I;

  resultDx(0, 1).col(0).fill(lambda);

  resultDx(0, 2).col(0).fill(mu_2);
  
  return resultDx;
}

// [[Rcpp::export]]
arma::cube irdDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & I = x.col(0);
  const vec & R = x.col(1);
  const vec & D = x.col(2);

  const double beta = theta(0);
  const double h = theta(1);
  const double mu_2 = theta(2);
  const double lambda = theta(3);


  // dxdt.col(0) = beta * (1 - I  - R  - D ) % (Itau(0) * I) - mu_2 * I - lambda * I;
  // dxdt.col(1) = lambda * I;
  // dxdt.col(2) = mu_2 * I;

  field<sp_mat> Itau = calcDelay(tvec, h);

  resultDtheta.slice(0).col(0) = (1 - I  - R  - D) % (Itau(0) * I);
  resultDtheta.slice(0).col(1) = beta * (1 - I  - R  - D )  % (Itau(1) * I);
  resultDtheta.slice(0).col(2) = - I;
  resultDtheta.slice(0).col(3) = - I;

  resultDtheta.slice(1).col(3) = I;

  resultDtheta.slice(2).col(2) = I;


  return resultDtheta;
}



// [[Rcpp::export]]
arma::mat lacoperonDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double gamma_A = 0.52; // gamma_A
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_M = 9.97e-4; // alpha_M
  const double alpha_A = 1.76e4; // alpha_A
  const double alpha_B  = 0.0166; // alpha_B
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double alpha_P = 10; // alpha_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1
  
  const double n = 2; // n
  const double mu_bar = 0.0226; 

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  dxdt.col(0) = alpha_M * (1 + K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) / (K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) + gamma_0 - (gamma_M + mu_bar) * M;
  dxdt.col(1) = alpha_B * exp(-mu_bar * tau_B) * Btau(0) * M - (gamma_B + mu_bar) * B;
  dxdt.col(2) = alpha_A * B % L / (K_L + L) - beta_A * B % A / (K_A + A) - (gamma_A + mu_bar) * A;  
  dxdt.col(3) = alpha_L * P * L_e/(K_Le + L_e) - beta_L1 * P % L / (K_L1 + L) - beta_L2 * B % L / (K_L + L) - (gamma_L + mu_bar) * L;
  dxdt.col(4) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0) * M - (gamma_P + mu_bar) * P;
  
  // Rcpp::Rcout << "dxdt = " << Atau << std::endl;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> lacoperonDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
  for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if ( ((i == 0) && (j == 2)) || ((i == 1) && (j == 0)) || ((i == 4) && (j == 0)))
        resultDx(j,i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j,i) = mat(x.n_rows, 1);
    }
  }

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double gamma_A = 0.52; // gamma_A
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_M = 9.97e-4; // alpha_M
  const double alpha_A = 1.76e4; // alpha_A
  const double alpha_B  = 0.0166; // alpha_B
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double alpha_P = 10; // alpha_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1
  
  const double n = 2; // n
  const double mu_bar = 0.0226; 

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  mat Mtau0A = Mtau(0) * A;

  resultDx(0,0).col(0).fill(-(gamma_M + mu_bar));
  //resultDx(2,0) = alpha_M * (K-1) *  n * K_1 * (Mtau(0).each_col() % ( pow(exp(-mu_bar * tau_M) * Mtau0A, n-1) * exp(-mu_bar * tau_M) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n)))).t();
  resultDx(2,0) =  alpha_M * (K-1) *  n * K_1 * Mtau(0).t() * diagmat( pow(exp(-mu_bar * tau_M) * Mtau0A, n-1) * exp(-mu_bar * tau_M) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n)));
  
  resultDx(0,1) = alpha_B * exp(-mu_bar * tau_B) * Btau(0).t();
  resultDx(1,1).col(0).fill(-(gamma_B + mu_bar));
  
  resultDx(1,2).col(0) = (alpha_A * L / (K_L + L) - beta_A * A / (K_A + A));
  resultDx(2,2).col(0) = (- beta_A * B * K_A / pow(K_A + A, 2) - (gamma_A + mu_bar));
  resultDx(3,2).col(0) = (alpha_A * B * K_L / pow(K_L + L, 2));

  resultDx(1,3).col(0) = (-beta_L2 * L/(K_L + L));
  resultDx(3,3).col(0) = (-beta_L1 * P * K_L1 / pow(K_L1 + L, 2) -  beta_L2 * B * K_L / pow(K_L + L, 2) - (gamma_L + mu_bar));
  resultDx(4,3).col(0) = (alpha_L * L_e/(K_Le + L_e) - beta_L1 * L/(K_L1 + L));
  
  resultDx(0,4) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0).t();
  resultDx(4,4).col(0).fill(-(gamma_P + mu_bar));

  return resultDx;
}

// [[Rcpp::export]]
arma::cube lacoperonDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double gamma_A = 0.52; // gamma_A
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_M = 9.97e-4; // alpha_M
  const double alpha_A = 1.76e4; // alpha_A
  const double alpha_B  = 0.0166; // alpha_B
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double alpha_P = 10; // alpha_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1resultDx(0) = M_0;
  
  const double n = 2; // n
  const double mu_bar = 0.0226; 

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  mat Mtau0A = Mtau(0) * A;

  resultDtheta.slice(0).col(1) = alpha_M * (K-1) * n * K_1 * ( pow(exp(-mu_bar * tau_M) * Mtau0A, n-1) * exp(-mu_bar * tau_M) % (Mtau(1) * A - mu_bar * Mtau0A)) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n));

  resultDtheta.slice(1).col(0) = alpha_B * exp(-mu_bar * tau_B) * (Btau(1) * M - mu_bar * Btau(0) * M) ;

  resultDtheta.slice(4).col(0) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * (BPtau(1) * M - mu_bar * BPtau(0) * M) ;
  resultDtheta.slice(4).col(2) = resultDtheta.slice(4).col(0);


  return resultDtheta;
}


// [[Rcpp::export]]
arma::mat lacoperonparsDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  mat dxdt(x.n_rows, x.n_cols);

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);
  const double gamma_A = theta(3);
  const double alpha_M = theta(4);
  const double alpha_B = theta(5);
  const double alpha_P = theta(6);
  const double mu_bar = theta(7);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_A = 1.76e4; // alpha_A
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1
  
  const double n = 2; // n

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  dxdt.col(0) = alpha_M * (1 + K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) / (K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) + gamma_0 - (gamma_M + mu_bar) * M;
  dxdt.col(1) = alpha_B * exp(-mu_bar * tau_B) * Btau(0) * M - (gamma_B + mu_bar) * B;
  dxdt.col(2) = alpha_A * B % L / (K_L + L) - beta_A * B % A / (K_A + A) - (gamma_A + mu_bar) * A;  
  dxdt.col(3) = alpha_L * P * L_e/(K_Le + L_e) - beta_L1 * P % L / (K_L1 + L) - beta_L2 * B % L / (K_L + L) - (gamma_L + mu_bar) * L;
  dxdt.col(4) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0) * M - (gamma_P + mu_bar) * P;
  
  // Rcpp::Rcout << "dxdt = " << Atau << std::endl;

  return dxdt;
}

// [[Rcpp::export]]
arma::field<arma::mat> lacoperonparsDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  field<mat> resultDx(x.n_cols, x.n_cols);
  for (int i = 0; i < x.n_cols; i++) {
    for (int j = 0; j < x.n_cols; j++) {
      if ( ((i == 0) && (j == 2)) || ((i == 1) && (j == 0)) || ((i == 4) && (j == 0)))
        resultDx(j,i) = mat(x.n_rows, x.n_rows);
      else
        resultDx(j,i) = mat(x.n_rows, 1);
    }
  }

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);
  const double gamma_A = theta(3);
  const double alpha_M = theta(4);
  const double alpha_B = theta(5);
  const double alpha_P = theta(6);
  const double mu_bar = theta(7);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_A = 1.76e4; // alpha_A
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1
  
  const double n = 2; // n

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  mat Mtau0A = Mtau(0) * A;

  resultDx(0,0).col(0).fill(-(gamma_M + mu_bar));
  resultDx(2,0) =  alpha_M * (K-1) *  n * K_1 * Mtau(0).t() * diagmat( pow(exp(-mu_bar * tau_M) * Mtau0A, n-1) * exp(-mu_bar * tau_M) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n)));
  
  resultDx(0,1) = alpha_B * exp(-mu_bar * tau_B) * Btau(0).t();
  resultDx(1,1).col(0).fill(-(gamma_B + mu_bar));
  
  resultDx(1,2).col(0) = (alpha_A * L / (K_L + L) - beta_A * A / (K_A + A));
  resultDx(2,2).col(0) = (- beta_A * B * K_A / pow(K_A + A, 2) - (gamma_A + mu_bar));
  resultDx(3,2).col(0) = (alpha_A * B * K_L / pow(K_L + L, 2));

  resultDx(1,3).col(0) = (-beta_L2 * L/(K_L + L));
  resultDx(3,3).col(0) = (-beta_L1 * P * K_L1 / pow(K_L1 + L, 2) -  beta_L2 * B * K_L / pow(K_L + L, 2) - (gamma_L + mu_bar));
  resultDx(4,3).col(0) = (alpha_L * L_e/(K_Le + L_e) - beta_L1 * L/(K_L1 + L));
  
  resultDx(0,4) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0).t();
  resultDx(4,4).col(0).fill(-(gamma_P + mu_bar));

  return resultDx;
}

// [[Rcpp::export]]
arma::cube lacoperonparsDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec) {
  cube resultDtheta(x.n_rows, theta.size(), x.n_cols);

  const vec & M = x.col(0);
  const vec & B = x.col(1);
  const vec & A = x.col(2);
  const vec & L = x.col(3);
  const vec & P = x.col(4);
  
  const double tau_B = theta(0);
  const double tau_M = theta(1);
  const double tau_P = theta(2);
  const double gamma_A = theta(3);
  const double alpha_M = theta(4);
  const double alpha_B = theta(5);
  const double alpha_P = theta(6);
  const double mu_bar = theta(7);

  const double L_e = 0.08;
  const double gamma_M =  0.411; // gamma_M
  const double K = 7200; // K
  const double K_L1 = 1.81; // K_L1
  const double K_A = 1.95; // K_A
  
  const double gamma_L = 0; // gamma_L
  const double alpha_L = 2880; // alpha_L
  const double K_Le = 0.26; // K_Le
  const double gamma_B = 8.33e-4; // gamma_B
  const double gamma_0 = 7.25e-7; // gamma_0
  
  const double alpha_A = 1.76e4; // alpha_A
  const double beta_A = 2.15e4; // beta_A
  const double K_L = 0.97; // K_L
  
  const double gamma_P = 0.65; // gamma_P
  const double beta_L1 =  2650; // beta_L1
  const double beta_L2 = 17600; // beta_L2
  const double K_1 = 25200; // K_1
  
  const double n = 2; // n

  field<sp_mat> Btau = calcDelay(tvec, tau_B);
  field<sp_mat> Mtau = calcDelay(tvec, tau_M);
  field<sp_mat> BPtau = calcDelay(tvec, tau_B + tau_P);

  mat Mtau0A = Mtau(0) * A;

  // dxdt.col(0) = alpha_M * (1 + K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) / (K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau(0) * A, n)) + gamma_0 - (gamma_M + mu_bar) * M;
  // dxdt.col(1) = alpha_B * exp(-mu_bar * tau_B) * Btau(0) * M - (gamma_B + mu_bar) * B;
  // dxdt.col(2) = alpha_A * B % L / (K_L + L) - beta_A * B % A / (K_A + A) - (gamma_A + mu_bar) * A;  
  // dxdt.col(3) = alpha_L * P * L_e/(K_Le + L_e) - beta_L1 * P % L / (K_L1 + L) - beta_L2 * B % L / (K_L + L) - (gamma_L + mu_bar) * L;
  // dxdt.col(4) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0) * M - (gamma_P + mu_bar) * P;

  resultDtheta.slice(0).col(1) = alpha_M * (K-1) * n * K_1 * ( pow(exp(-mu_bar * tau_M) * Mtau0A, n-1) * exp(-mu_bar * tau_M) % (Mtau(1) * A - mu_bar * Mtau0A)) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n));

  resultDtheta.slice(1).col(0) = alpha_B * exp(-mu_bar * tau_B) * (Btau(1) * M - mu_bar * Btau(0) * M) ;

  resultDtheta.slice(4).col(0) = alpha_P * exp(-mu_bar * (tau_B + tau_P)) * (BPtau(1) * M - mu_bar * BPtau(0) * M) ;
  resultDtheta.slice(4).col(2) = resultDtheta.slice(4).col(0);

  resultDtheta.slice(2).col(3) = -A;
  resultDtheta.slice(0).col(4) = (1 + K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n)) / (K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n));
  resultDtheta.slice(1).col(5) = exp(-mu_bar * tau_B) * Btau(0) * M;
  resultDtheta.slice(4).col(6) = exp(-mu_bar * (tau_B + tau_P)) * BPtau(0) * M;

  resultDtheta.slice(0).col(7) =  alpha_M * (K-1) * n * K_1 * ( pow(exp(-mu_bar * tau_M) * Mtau0A, n) * (-tau_M)) / square(K+ K_1 * pow(exp(-mu_bar * tau_M) * Mtau0A, n)) - M;
  resultDtheta.slice(1).col(7) =  - tau_B * alpha_B * exp(-mu_bar * tau_B) * Btau(0) * M - B;
  resultDtheta.slice(2).col(7) =  - A;
  resultDtheta.slice(3).col(7) =  - L;
  resultDtheta.slice(4).col(7) = -(tau_B + tau_P) * alpha_P * exp(-mu_bar * (tau_B + tau_P)) * BPtau(0) * M - P;

  return resultDtheta;
}

