#ifndef DYNAMICALSYSTEMMODELS_H
#define DYNAMICALSYSTEMMODELS_H

#include "classDefinition.h"

arma::field<arma::sp_mat> calcDelay(const arma::vec & tvec, double tau);

arma::mat lvDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> lvDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube lvDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat sirDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> sirDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube sirDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat sirtwoDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> sirtwoDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube sirtwoDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat sirtwobwoDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> sirtwobwoDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube sirtwobwoDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat sirdDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> sirdDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube sirdDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat irdDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> irdDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube irdDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat lacoperonDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> lacoperonDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube lacoperonDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);

arma::mat lacoperonparsDDE(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::field<arma::mat> lacoperonparsDDx(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);
arma::cube lacoperonparsDDtheta(const arma::vec & theta, const arma::mat & x, const arma::vec & tvec);


#endif
