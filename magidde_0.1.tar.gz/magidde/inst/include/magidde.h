#ifndef RCPP_MAGIDDE_H
#define RCPP_MAGIDDE_H

#include "../../src/RcppTranslation.h"

#endif // RCPP_MAGI_H
